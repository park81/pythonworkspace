import csv
import requests
from bs4 import BeautifulSoup

def create_soup(url):
    headers ={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36"}
    res = requests.get(url,headers=headers)
    res.raise_for_status()
    soup = BeautifulSoup(res.text, "lxml")
    return soup

filename = "총액_주식.csv"
f = open(filename, "w", encoding="utf-8-sig", newline="") #각 줄마다 Enter들어간다 newline=""빼면 / 엑셀에서 한글 깨지면 utf-8-sig 로 바꾸기
writer = csv.writer(f)

for i in range(0,2):

    url_init = "https://finance.naver.com/sise/sise_market_sum.nhn?sosok={}&page=".format(i)
  
    if i ==0:
        stock_name=["코스피"]
        writer.writerow(stock_name)
    else:
        stock_name=["코스닥"]
        writer.writerow(stock_name)

    title = "종목명	2017.12	2018.12	2019.12	2020.12(E)	2019.06	2019.09	2019.12	2020.03	2020.06	2020.09(E)	시가총액	링크".split("\t")
    print(type(title))
    writer.writerow(title)

    for i in range(1,30):
        url=url_init+str(i)
        soup = create_soup(url)
        print(url)
        data_rows = soup.find("table", attrs = {"class":"type_2"}).find("tbody").find_all("tr")
        for row in data_rows:
            columns = row.find_all("td")

            if len(columns) <=1: #의미 없는 데이터는 skip
                continue
            else:
                if columns[10].get_text().strip()=="N/A":
                    continue
                elif float(columns[10].get_text().strip().replace(",","")) > 0:
                    name = columns[1].get_text().strip()
                    total_stock=columns[6].get_text().strip()
                    code_num = row.find("a",attrs={"class":"tltle"})["href"]
                    link = "https://finance.naver.com"+code_num
                    soup2 = create_soup(link)
                    print(name)
                    print(link)
                    if soup2.find("table",attrs={"class":"tb_type1 tb_num tb_type1_ifrs"}):
                        data_rows2 = soup2.find("table",attrs={"class":"tb_type1 tb_num tb_type1_ifrs"}).find("tbody").find_all("tr")
                    else:
                        continue
                    #print(data_rows2)

                    # with open("stock.html", "w", encoding="utf8") as f:
                    #    f.write(data_rows2.prettify()) #html 문서를 예쁘게 출력

                # data_rows2 = find("tbody")
                    #soup2.find("table", attrs = {"class":"tbl","id":"cTB25"})#.find("tbody").find_all("tr")
                # print(data_rows2)
                # print(data_rows2[4].get_text)
                    last=[]
                    for idx, row2 in enumerate(data_rows2):
                        columns2 = row2.find_all("td")

                        if len(columns2) <=1: #의미 없는 데이터는 skip
                            continue
                        else:
                            result= [column.get_text().strip() for column in columns2]
                            #print(result)
                            if idx == 1:
                                result.insert(0,name)
                                result.append(total_stock)
                                

                            last.append(result)                       
                    if "" in last[1]:
                        continue
                        #int(last[1][1].replace(",",""))<
                        #and int(last[1][8].replace(",",""))<int(last[1][9].replace(",",""))
                        #<int(last[1][4].replace(",","")
                    else:
                        if int(last[1][2].replace(",",""))<int(last[1][3].replace(",","")) and int(20*(int(last[1][8].replace(",",""))+int(last[1][9].replace(",",""))))>int(last[1][11].replace(",","")) and int(last[1][8].replace(",",""))<int(last[1][9].replace(",",""))<int(last[1][10].replace(",","")) and 0<int(last[1][4].replace(",","")):
                            last[1].append(link.strip())
                            writer.writerow(last[1]) #data를 list 형태로 넣어주면 된다.
                            print(last[1])
                else:
                    continue
    #break

# filename = "시가총액1-200.csv"
# f = open(filename, "w", encoding="utf-8-sig", newline="") #각 줄마다 Enter들어간다 newline=""빼면 / 엑셀에서 한글 깨지면 utf-8-sig 로 바꾸기
# writer = csv.writer(f)

# title = "N	종목명	현재가	전일비	등락률	액면가	시가총액	상장주식수	외국인비율	거래량	PER	ROE".split("\t")
# #["N", "종목명", .....]
# print(type(title))
# writer.writerow(title)


# for page in range(1, 5):
#     res = requests.get(url+str(page))
#     res.raise_for_status()
#     soup = BeautifulSoup(res.text,"lxml")

#     data_rows = soup.find("table", attrs = {"class":"type_2"}).find("tbody").find_all("tr")
#     for row in data_rows:
#         columns = row.find_all("td")
#         if len(columns) <=1: #의미 없는 데이터는 skip
#             continue
#         data = [column.get_text().strip() for column in columns] #strip() -> 불필요한공백 제거
#         writer.writerow(data) #data를 list 형태로 넣어주면 된다.